/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consolesalesapp;

/**
 *
 * @author Student
 */
    public abstract class Console implements IConsoles {
    // variables
    protected String consoleType;
    protected String storeName;
    protected int totalSales;

    // Constructor with parameters
    public Console(String consoleType, String storeName, int totalSales) {
        this.consoleType = consoleType;
        this.storeName = storeName;
        this.totalSales = totalSales;
    }

    // Methods to get values - implements interface
    @Override
    public String getConsoleType() {
        return consoleType;
    }

    @Override
    public String getStore() {
        return storeName;
    }

    @Override
    public int getTotalSales() {
        return totalSales;
    }

    // Abstract method to print report - child must implement
    public abstract void printReport();

}
