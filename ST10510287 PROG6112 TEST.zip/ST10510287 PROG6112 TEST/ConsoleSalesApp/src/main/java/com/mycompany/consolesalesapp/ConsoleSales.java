/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consolesalesapp;
import java.util.Scanner;

/**
 *
 * @author Student
 */
    
// Child class
class ConsoleSales extends Console {

    public ConsoleSales(String consoleType, String storeName, int totalSales) {
        super(consoleType, storeName, totalSales);
    }

    @Override
    public void printReport() {
        System.out.println("\n=====================================");
        System.out.println("   GAMING CONSOLE REPORT");
        System.out.println("=====================================");
        System.out.println("Store Name      : " + getStore());
        System.out.println("Console Type    : " + getConsoleType());
        System.out.println("Total Sales     : " + getTotalSales() + " units");
        System.out.println("=====================================");
    }
}

