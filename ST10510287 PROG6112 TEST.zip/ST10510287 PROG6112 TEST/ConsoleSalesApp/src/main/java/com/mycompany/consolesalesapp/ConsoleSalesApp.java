/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.consolesalesapp;
import java.util.Scanner;

 public class ConsoleSalesApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== ELECTRONICS STORE - CONSOLE SALES ===");
        System.out.println("Select Console Device Type:");
        System.out.println("1. PS5");
        System.out.println("2. XBOX");
        System.out.println("3. Nintendo Switch");
        System.out.print("Enter choice (1-3): ");
        int choice = sc.nextInt();
        sc.nextLine(); // clear buffer

        String consoleType;
        switch (choice) {
            case 1: consoleType = "PS5"; break;
            case 2: consoleType = "XBOX"; break;
            case 3: consoleType = "Nintendo Switch"; break;
            default: consoleType = "Unknown Console"; break;
        }

        System.out.print("Enter Store Name (e.g., Cape Town, Pretoria, Port Elizabeth): ");
        String storeName = sc.nextLine();

        System.out.print("Enter Total Amount of Sales: ");
        int totalSales = sc.nextInt();

        // Create object
        ConsoleSales sale = new ConsoleSales(consoleType, storeName, totalSales);
        
        // Print using abstract class method
        sale.printReport();

        sc.close();
    }
}
    

