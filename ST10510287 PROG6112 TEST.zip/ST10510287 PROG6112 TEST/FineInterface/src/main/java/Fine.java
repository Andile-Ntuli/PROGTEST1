/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class Fine {
   
   
    private String customerName;
    private int speed;
    private double speeding;
      

    public Fine(String customerName, int talkTime, double pricePerMinute) {
        this.customerName = customerName;
        this.speed = speed;
        this.speeding= speeding;
    }

    // Getters - needed because variables are private
    public String getCustomerName() { return customerName; }
    public int getTalkTime() { return speed; }
    public double getPricePerMinute() { return speeding; }
    }
    


    
