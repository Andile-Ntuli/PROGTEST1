/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fineinterface;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class FineInterface {

   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       
        System.out.print("Enter customer name: ");
        String name = sc.nextLine();
        
        System.out.print("Enter speed (minutes): ");
        int talkTime = sc.nextInt();
        
        System.out.print("Enter speeding: ");
        double pricePerMinute = sc.nextDouble();
        
        sc.nextLine();
        
        System.out.print("Enter network type (e.g, MTN, Vodacom): ");
        String network = sc.nextLine();
        
     

        sc.close();
    }

    private void printBill() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}