/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fineinterface;

/**
 *
 * @author Student
 */
public class Fine_Interface extends FineInterface {

    private String networkType;

    public Fine_Interface(String name, int speed, double cost, String network) {
           this.networkType = networkType;
    }

    // Method to calculate total amount
    public double cost() {
        return speed() * speeding();
    }

    // Method to print the bill
    public void FineBill() {
        System.out.println("\n----- CELL PHONE BILL -----");
        System.out.println("Network: " + networkType);
        System.out.println("Talk Time: " + speed() + " minutes");
        System.out.println("Price per Minute: R" + speeding());
        System.out.println("Total Amount Due: R" + cost());
        System.out.println("---------------------------");
    }

    private double speed() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private double speeding() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    
    

